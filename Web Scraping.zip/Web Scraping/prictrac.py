import requests
from bs4 import BeautifulSoup


class PriceTracter:
    def __init__(self,url):
        self.url = url
        self.user_agent = {"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"}
        self.response = requests.get(self.url,headers = self.user_agent).text
        self.soup = BeautifulSoup(self.response,"lxml")

    def product_title(self):
        title = self.soup.find("span",{"id":"productTitle"})
        if title is not None:
            return title.text.strip()
        else:
            return "Tag Not found"

    def product_price(self):
        price = self.soup.find("span",{"class":"a-price-whole"})
        if price is not None:
            return price.text.strip()
        else:
            return "Tag Not found"
        


device = PriceTracter(url="https://www.amazon.in/HP-Pavilion-i5-1335U-Laptop-Touchscreen/dp/B0CJ2KWNNQ/ref=sr_1_1_sspa?crid=H04M8FNYJ84B&dib=eyJ2IjoiMSJ9.goBbAx1cx1XHd55iXTWIB2Dz02mVdzGkrC-M2A27IbCgb0aKRrKNZWZZlfciD4iNN1o7pXpaKxxQ1Gia5U9zwY0NcUfYZb7FhUbtvhbfctCgNPIAjvfIKpfMeCSU4ij9bgiIoDTCFGJ2eKO07C4YIS947Tm8nvZfpOjR9aTiWPnhKAzjEfLrcChzFsTZFtMFMV164mNdesPNYr-LX3JRansL7a9KvNV97hKw0nbz-_A.2yQbOZZ18j0vyHE8KdGPLB457EKU_V3cCtsSq1akJcU&dib_tag=se&keywords=laptop%2Bfoldable&qid=1751038057&sprefix=laptop%2Bfol%2Caps%2C264&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1")
print(device.product_title())
print(device.product_price())